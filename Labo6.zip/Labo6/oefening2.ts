let names: string[] = ['joske','franske','donald','achmed']

names.forEach(element => 
    console.log(element.toUpperCase())
)

names.map(element => 
    console.log(element.toUpperCase())
)

